import pandas as pd
import numpy as np

# Load dataset
df = pd.read_csv("dirty_cafe_sales.csv")

# Replace invalid values with NaN
df.replace(["ERROR", "UNKNOWN", "None", ""], np.nan, inplace=True)

# Remove extra spaces and standardize text columns
text_columns = ["Item", "Payment Method", "Location"]

for col in text_columns:
    df[col] = df[col].astype("string").str.strip().str.title()

# Convert numeric columns
df["Price Per Unit"] = pd.to_numeric(df["Price Per Unit"], errors="coerce")
df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")

# Menu item prices
price_map = {
    "Coffee": 2.0,
    "Tea": 1.5,
    "Sandwich": 4.0,
    "Salad": 5.0,
    "Cake": 3.0,
    "Cookie": 1.0,
    "Smoothie": 4.0,
    "Juice": 3.0
}

# Fill missing Item based on Price Per Unit
price_to_item = {
    1.0: "Cookie",
    1.5: "Tea",
    2.0: "Coffee",
    5.0: "Salad"
}

df.loc[df["Item"].isna(), "Item"] = df.loc[df["Item"].isna(), "Price Per Unit"].map(price_to_item)

# For shared prices
df.loc[(df["Item"].isna()) & (df["Price Per Unit"] == 3.0), "Item"] = "Cake/Juice"
df.loc[(df["Item"].isna()) & (df["Price Per Unit"] == 4.0), "Item"] = "Sandwich/Smoothie"

# Correct price based on menu item
df["Price Per Unit"] = df["Item"].map(price_map).fillna(df["Price Per Unit"])

# Fill missing numeric values with median
df["Price Per Unit"] = df["Price Per Unit"].fillna(df["Price Per Unit"].median())
df["Quantity"] = df["Quantity"].fillna(df["Quantity"].median())

# Fill missing categorical values
df["Payment Method"] = df["Payment Method"].fillna(df["Payment Method"].mode()[0])
df["Location"] = df["Location"].fillna(df["Location"].mode()[0])

# Convert transaction date
df["Transaction Date"] = pd.to_datetime(
    df["Transaction Date"],
    errors="coerce",
    dayfirst=True
)

# Fill blank dates using middle/interpolated dates
df["Transaction Date"] = df["Transaction Date"].interpolate(method="linear")
df["Transaction Date"] = df["Transaction Date"].ffill().bfill()

# Sort transaction date from January to December
df.sort_values(by="Transaction Date", inplace=True)
df.reset_index(drop=True, inplace=True)

# Create new date features
df["Day Of Week"] = df["Transaction Date"].dt.day_name()
df["Transaction Month"] = df["Transaction Date"].dt.month_name()

# Keep only date format, no time
df["Transaction Date"] = df["Transaction Date"].dt.strftime("%d/%m/%Y")

# Remove duplicate rows
df.drop_duplicates(inplace=True)

# Check missing values after cleaning
print("Missing values after cleaning:")
print(df.isnull().sum())

# Save cleaned dataset
df.to_csv("cleaned_cafe_sales_final.csv", index=False)

print("Cleaning completed. File saved as cleaned_cafe_sales_final.csv")